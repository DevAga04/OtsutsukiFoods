package com.otsutsuki.food.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query


@Dao
interface FavRestaurantDao {

    @Insert
    fun insertRestaurant(favRestaurantEntity: FavRestaurantEntity)

    @Delete
    fun deleteRestaurant(favRestaurantEntity: FavRestaurantEntity)

    @Query("SELECT * FROM favRestaurants")
    fun getAllRestaurant(): List<FavRestaurantEntity>

    @Query("SELECT * FROM favRestaurants WHERE id = :resId")
    fun getResById(resId: String): FavRestaurantEntity
}