package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.adapter.DetailRecycleAdapter
import com.otsutsuki.food.model.Detail
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException

class ResDetailsActivity : AppCompatActivity() {

    private lateinit var toolbarDetail: Toolbar
    lateinit var recyclerDetails: RecyclerView
    lateinit var proceedToCartLayout: RelativeLayout
    lateinit var btnAddToCart: Button
    private lateinit var progressBar: ProgressBar
    lateinit var progressLayout: RelativeLayout


    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recycleAdapter: DetailRecycleAdapter

    private var resId = "1"
    private var resName = "1"

    val detailsList = arrayListOf<Detail>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_res_details)

        val sharedPreferences =
            getSharedPreferences(getString(R.string.shared_preferences), MODE_PRIVATE)

        progressBar = findViewById(R.id.detailProgressBar)
        progressLayout = findViewById(R.id.detailProgressLayout)
        toolbarDetail = findViewById(R.id.detailToolbar)

        btnAddToCart = findViewById(R.id.btnAddToCart)
        proceedToCartLayout = findViewById(R.id.proceedToCartLayout)




        progressLayout.visibility = View.VISIBLE


        resId = sharedPreferences.getString("favourite_res_id", "0").toString()
        resName = sharedPreferences.getString("favourite_res_name", "0").toString()

        setSupportActionBar(toolbarDetail)
        supportActionBar?.title = resName
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)



        recyclerDetails = findViewById(R.id.detailRecyclerView)
        layoutManager = LinearLayoutManager(this@ResDetailsActivity)

        val queue = Volley.newRequestQueue(this@ResDetailsActivity)

        val url = " http://13.235.250.119/v2/restaurants/fetch_result/${resId}"



        if (ConnectionManager().checkConnectivity(this@ResDetailsActivity)) {
            val jsonObjectRequest =
                object : JsonObjectRequest(Method.GET, url, null, Response.Listener {


                    try {
                        progressLayout.visibility = View.GONE

                        val detailsData = it.getJSONObject("data")

                        val success = detailsData.getBoolean("success")


                        var srNo = 1

                        if (success) {
                            detailsList.clear()
                            val data = detailsData.getJSONArray("data")
                            for (i in 0 until data.length()) {

                                val dishJsonObject = data.getJSONObject(i)
                                val dishObject = Detail(
                                    srNo,
                                    dishJsonObject.getString("id"),
                                    dishJsonObject.getString("name"),
                                    dishJsonObject.getString("cost_for_one"),
                                    dishJsonObject.getString("restaurant_id")
                                )
                                detailsList.add(dishObject)

                                recycleAdapter = DetailRecycleAdapter(
                                    this@ResDetailsActivity,
                                    detailsList,
                                    proceedToCartLayout,
                                    btnAddToCart,
                                    resId,
                                    resName
                                )

                                recyclerDetails.adapter = recycleAdapter

                                recyclerDetails.layoutManager = layoutManager
                                srNo++
                            }


                        } else {
                            Toast.makeText(
                                this,
                                "Some error has Occurred!!!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(
                            this@ResDetailsActivity,
                            "Some unexpected error occurred!!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }


                }, Response.ErrorListener {
                    Toast.makeText(
                        this@ResDetailsActivity,
                        "Some Error occurred!!!",
                        Toast.LENGTH_SHORT
                    ).show()
                }) {

                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "2ecc7402475386"
                        return headers
                    }

                }

            queue.add(jsonObjectRequest)

        } else {

            val dialog = AlertDialog.Builder(this@ResDetailsActivity)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Open Settings") { _, _ ->

                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                finish()

            }
            dialog.setNegativeButton("Exit") { _, _ ->
                ActivityCompat.finishAffinity(this@ResDetailsActivity)
            }
            dialog.create()
            dialog.show()
        }


    }

    override fun onBackPressed() {
        if (recycleAdapter.getSelectedItemCount() > 0) {
            val alertDialog = AlertDialog.Builder(this)
            alertDialog.setTitle("Alert!")
            alertDialog.setMessage("Going back will will reset cart items. Do you wish to continue?")
            alertDialog.setPositiveButton("Okay") { _, _ ->
                super.onBackPressed()
            }
            alertDialog.setNegativeButton("Cancel") { _, _ ->

            }
            alertDialog.show()
        } else {
            super.onBackPressed()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                if (recycleAdapter.getSelectedItemCount() > 0) {
                    val alertDialog = AlertDialog.Builder(this)
                    alertDialog.setTitle("Alert!")
                    alertDialog.setMessage("Going back will will reset cart items. Do you wish to continue?")
                    alertDialog.setPositiveButton("Okay") { _, _ ->
                        super.onBackPressed()
                    }
                    alertDialog.setNegativeButton("Cancel") { _, _ ->

                    }
                    alertDialog.show()
                } else {
                    super.onBackPressed()
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }


}