package com.otsutsuki.food.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.model.CartItems
import com.otsutsuki.food.model.OrderHistoryRestaurant
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException

class OrderHistoryRecyclerAdapter(
    val context: Context,
    val orderedRestaurantList: ArrayList<OrderHistoryRestaurant>
) : RecyclerView.Adapter<OrderHistoryRecyclerAdapter.OrderHistoryViewHolder>() {

    class OrderHistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtDate: TextView = view.findViewById(R.id.txtDate)
        val recyclerViewItemOrdered: RecyclerView = view.findViewById(R.id.recyclerViewItemsOrdered)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderHistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_order_history_single_row, parent, false)

        return OrderHistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderHistoryViewHolder, position: Int) {

        val restaurantObject = orderedRestaurantList[position]
        holder.txtRestaurantName.text = restaurantObject.restaurantName
        var date = restaurantObject.orderDate
        date = date.replace("-", "/")
        date = date.substring(0, 6) + "20" + date.substring(6, 8)
        holder.txtDate.text = date

        val layoutManager = LinearLayoutManager(context)
        var orderedDishAdapter: CartRecyclerAdapter

        if (ConnectionManager().checkConnectivity(context)) {

            try {
                val orderDishPerRestaurant = ArrayList<CartItems>()
                val sharedPreferences = context.getSharedPreferences(
                    context.getString(R.string.shared_preferences),
                    Context.MODE_PRIVATE
                )

                val userId = sharedPreferences.getString("user_id", "0")
                val queue = Volley.newRequestQueue(context)
                val url = "http://13.235.250.119/v2/orders/fetch_result/$userId"

                val jsonObjectRequest = object : JsonObjectRequest(
                    Method.GET, url, null, Response.Listener {

                        val response = it.getJSONObject("data")
                        val success = response.getBoolean("success")

                        if (success) {

                            val data = response.getJSONArray("data")
                            val restaurantRetrievedObject = data.getJSONObject(position)
                            orderDishPerRestaurant.clear()
                            val foodOrdered = restaurantRetrievedObject.getJSONArray("food_items")

                            for (j in 0 until foodOrdered.length()) {
                                val eachFoodItem = foodOrdered.getJSONObject(j)
                                val itemObject = CartItems(
                                    eachFoodItem.getString("food_item_id"),
                                    eachFoodItem.getString("name"),
                                    eachFoodItem.getString("cost"), "000"
                                )


                                orderDishPerRestaurant.add(itemObject)

                            }

                            orderedDishAdapter =
                                CartRecyclerAdapter(context, orderDishPerRestaurant)
                            holder.recyclerViewItemOrdered.adapter = orderedDishAdapter
                            holder.recyclerViewItemOrdered.layoutManager = layoutManager

                        }

                    }, Response.ErrorListener {
                        Toast.makeText(
                            context,
                            "Some Error occurred!!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "2ecc7402475386"
                        return headers
                    }
                }

                queue.add(jsonObjectRequest)
            } catch (e: JSONException) {
                Toast.makeText(
                    context,
                    "Some Unexpected error occurred!!!",
                    Toast.LENGTH_SHORT
                ).show()
            }


        }

    }

    override fun getItemCount(): Int {
        return orderedRestaurantList.size
    }

}