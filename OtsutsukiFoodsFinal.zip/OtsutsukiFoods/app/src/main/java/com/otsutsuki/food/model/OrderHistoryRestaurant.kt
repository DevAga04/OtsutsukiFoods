package com.otsutsuki.food.model

data class OrderHistoryRestaurant(
    var orderId: String,
    var restaurantName: String,
    var totalCost: String,
    var orderDate: String
)