package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {

    private lateinit var etNameRegister: EditText
    private lateinit var etEmailRegister: EditText
    private lateinit var etMobileRegister: EditText
    private lateinit var etAddressRegister: EditText
    private lateinit var etPasswordRegister: EditText
    private lateinit var etPasswordRegisterConfirm: EditText

    private lateinit var btnRegister: Button


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        etNameRegister = findViewById(R.id.etNameRegister)
        etEmailRegister = findViewById(R.id.etEmailRegister)
        etMobileRegister = findViewById(R.id.etMobileRegister)
        etAddressRegister = findViewById(R.id.etAddressRegister)
        etPasswordRegister = findViewById(R.id.etPasswordRegister)
        etPasswordRegisterConfirm = findViewById(R.id.etPasswordRegisterConfirm)

        btnRegister = findViewById(R.id.btnRegister)



        btnRegister.setOnClickListener {

            val sharedPreferences =
                getSharedPreferences(getString(R.string.shared_preferences), MODE_PRIVATE)

            sharedPreferences.edit().putBoolean("isLoggedIn", false).apply()

            if (ConnectionManager().checkConnectivity(this)) {

                if (checkInputError()) {

                    try {
                        val registerUser = JSONObject()
                        registerUser.put("name", etNameRegister.text)
                        registerUser.put("mobile_number", etMobileRegister.text)
                        registerUser.put("password", etPasswordRegister.text)
                        registerUser.put("address", etAddressRegister.text)
                        registerUser.put("email", etEmailRegister.text)

                        val queue = Volley.newRequestQueue(this)
                        val url = "http://13.235.250.119/v2/register/fetch_result"

                        val jsonObjectRequest = object :
                            JsonObjectRequest(Method.POST, url, registerUser, Response.Listener {

                                print("response43 $it")
                                val response = it.getJSONObject("data")
                                val success = response.getBoolean("success")

                                if (success) {
                                    val data = response.getJSONObject("data")
                                    sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
                                    sharedPreferences.edit()
                                        .putString("user_id", data.getString("user_id")).apply()
                                    sharedPreferences.edit()
                                        .putString("name", data.getString("name")).apply()
                                    sharedPreferences.edit()
                                        .putString("email", data.getString("email")).apply()
                                    sharedPreferences.edit()
                                        .putString("mobile_number", data.getString("mobile_number"))
                                        .apply()
                                    sharedPreferences.edit()
                                        .putString("address", data.getString("address")).apply()

                                    Toast.makeText(
                                        this,
                                        "Registered Successfully",
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    userRegisteredSuccessfully()

                                } else {
                                    val errorResponse =
                                        response.getString("errorMessage")
                                    Toast.makeText(
                                        this,
                                        errorResponse,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                            }, Response.ErrorListener {
                                Toast.makeText(
                                    this,
                                    "Some Error occurred!!!",
                                    Toast.LENGTH_SHORT
                                ).show()

                            }) {
                            override fun getHeaders(): MutableMap<String, String> {
                                val headers = HashMap<String, String>()
                                headers["Content-type"] = "application/json"
                                headers["token"] = "2ecc7402475386"
                                return headers
                            }
                        }
                        queue.add(jsonObjectRequest)
                    } catch (e: JSONException) {

                        Toast.makeText(
                            this,
                            "Some unexpected error occurred!!!",
                            Toast.LENGTH_SHORT
                        ).show()

                    }

                }

            } else {
                val dialog = AlertDialog.Builder(this)
                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection not Found")
                dialog.setPositiveButton("Open Settings") { _, _ ->

                    val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingsIntent)
                    finish()

                }
                dialog.setNegativeButton("Exit") { _, _ ->
                    ActivityCompat.finishAffinity(this)
                }
                dialog.create()
                dialog.show()
            }

        }
    }

    fun userRegisteredSuccessfully() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun checkInputError(): Boolean {
        var noError = 0

        if (etNameRegister.text.isBlank()) {
            etNameRegister.error = "Name Missing"
        } else {
            noError++
        }

        if (etMobileRegister.text.isBlank() || etMobileRegister.text.length != 10) {
            etMobileRegister.error = "Invalid Mobile Number!"
        } else {
            noError++
        }

        if (etEmailRegister.text.isBlank()) {
            etEmailRegister.error = "Email Missing!"
        } else {
            noError++
        }

        if (etAddressRegister.text.isBlank()) {
            etAddressRegister.error = "Address Missing!"
        } else {
            noError++
        }

        if (etPasswordRegisterConfirm.text.isBlank()) {
            etPasswordRegisterConfirm.error = "Invalid Password"
        } else {
            noError++
        }

        if (etPasswordRegister.text.isBlank()) {
            etPasswordRegister.error = "Invalid Password"
        } else {
            noError++
        }

        if (etPasswordRegister.text.isNotBlank() && etPasswordRegisterConfirm.text.isNotBlank()) {
            if (etPasswordRegister.text.toString() == etPasswordRegisterConfirm.text.toString()) {
                noError++
            } else {
                etPasswordRegisterConfirm.error = "Password doesn't match"
            }
        }

        return noError == 7
    }
}


