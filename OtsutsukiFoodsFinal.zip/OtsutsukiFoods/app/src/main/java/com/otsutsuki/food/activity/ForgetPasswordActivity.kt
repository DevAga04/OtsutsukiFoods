package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException
import org.json.JSONObject

class ForgetPasswordActivity : AppCompatActivity() {

    private lateinit var etMobileForgot: EditText
    private lateinit var etEmailForgot: EditText
    private lateinit var btnForgotNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)

        etMobileForgot = findViewById(R.id.etMobileForgotPassword)
        etEmailForgot = findViewById(R.id.etEmailForgotPassword)
        btnForgotNext = findViewById(R.id.btnForgotNext)

        btnForgotNext.setOnClickListener {

            if (etMobileForgot.text.isBlank() || etMobileForgot.text.length != 10) {
                etMobileForgot.error = "Invalid Mobile Number"
            } else {
                if (etEmailForgot.text.isBlank()) {
                    etEmailForgot.error = "Invalid Email"
                } else {
                    if (ConnectionManager().checkConnectivity(this)) {
                        try {

                            val forgotUser = JSONObject()
                            forgotUser.put("mobile_number", etMobileForgot.text)
                            forgotUser.put("email", etEmailForgot.text)


                            val queue = Volley.newRequestQueue(this)
                            val url = "http://13.235.250.119/v2/forgot_password/fetch_result"

                            val jsonObjectRequest = object :
                                JsonObjectRequest(Method.POST, url, forgotUser, Response.Listener {

                                    val response = it.getJSONObject("data")
                                    val success = response.getBoolean("success")
                                    if (success) {

                                        val firstTime = response.getBoolean("first_try")

                                        if (firstTime) {
                                            Toast.makeText(this, "OTP Sent", Toast.LENGTH_SHORT)
                                                .show()

                                            otpSentSuccessfully()

                                        } else {
                                            Toast.makeText(
                                                this,
                                                "OTP Already Sent",
                                                Toast.LENGTH_SHORT
                                            )
                                                .show()

                                            otpSentSuccessfully()
                                        }

                                    } else {
                                        val errorResponse = response.getString("errorMessage")

                                        Toast.makeText(
                                            this,
                                            errorResponse.toString(),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }

                                }, Response.ErrorListener {
                                    Toast.makeText(this, "Some error occurred!", Toast.LENGTH_SHORT)
                                        .show()

                                }) {
                                override fun getHeaders(): MutableMap<String, String> {
                                    val headers = HashMap<String, String>()
                                    headers["Content-type"] = "application/json"
                                    headers["token"] = "2ecc7402475386"
                                    return headers
                                }

                            }
                            queue.add(jsonObjectRequest)

                        } catch (e: JSONException) {
                            Toast.makeText(
                                this,
                                "Some unexpected error occurred!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        val dialog = AlertDialog.Builder(this)
                        dialog.setTitle("Error")
                        dialog.setMessage("Internet Connection not Found")
                        dialog.setPositiveButton("Open Settings") { _, _ ->

                            val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                            startActivity(settingsIntent)
                            finish()

                        }
                        dialog.setNegativeButton("Exit") { _, _ ->
                            ActivityCompat.finishAffinity(this)
                        }
                        dialog.create()
                        dialog.show()
                    }
                }
            }


        }

    }

    fun otpSentSuccessfully() {
        val intent = Intent(this, ForgotNext::class.java)
        intent.putExtra("mobile_number", etMobileForgot.toString())
        intent.putExtra("email", etEmailForgot.toString())
        startActivity(intent)
    }
}