package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException
import org.json.JSONObject

class ForgotNext : AppCompatActivity() {

    private lateinit var etOTP: EditText
    private lateinit var etNewPassword: EditText
    lateinit var etConfirmPassword: EditText
    private lateinit var btnSubmit: Button

    private lateinit var etMobile: String
    private lateinit var etEmail: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_next)

        if (intent != null) {
            etMobile = intent.getStringExtra("mobile_number").toString()
            etEmail = intent.getStringExtra("email").toString()
        }

        etOTP = findViewById(R.id.etForgotOTP)
        etNewPassword = findViewById(R.id.etForgotPassword)
        etConfirmPassword = findViewById(R.id.etForgotPasswordConfirm)
        btnSubmit = findViewById(R.id.btnForgotOTP)

        btnSubmit.setOnClickListener {
            if (etOTP.text.isBlank()) {
                etOTP.error = "Incorrect OTP"
            } else {
                if (etNewPassword.text.isBlank() || etNewPassword.text.length <= 4) {
                    etNewPassword.error = "Invalid Password"
                } else {
                    if (etConfirmPassword.text.isBlank()) {
                        etConfirmPassword.error = "Invalid Confirm Password"
                    } else {
                        if (etNewPassword.text.toString() == etConfirmPassword.text.toString()) {

                            if (ConnectionManager().checkConnectivity(this)) {

                                try {
                                    val loginUser = JSONObject()
                                    loginUser.put("mobile_number", etMobile)
                                    loginUser.put("password", etNewPassword.text.toString())
                                    loginUser.put("otp", etOTP.text.toString())

                                    val queue = Volley.newRequestQueue(this)
                                    val url = "http://13.235.250.119/v2/reset_password/fetch_result"

                                    val jsonObjectRequest = object : JsonObjectRequest(
                                        Method.POST,
                                        url,
                                        loginUser,
                                        Response.Listener {

                                            val response = it.getJSONObject("data")
                                            val success = response.getBoolean("success")

                                            if (success) {
                                                val successResponse =
                                                    response.getString("successMessage")
                                                Toast.makeText(
                                                    this,
                                                    successResponse,
                                                    Toast.LENGTH_SHORT
                                                ).show()

                                                afterPasswordChange()
                                            } else {
                                                val errorResponse =
                                                    response.getString("errorMessage")

                                                Toast.makeText(
                                                    this,
                                                    errorResponse,
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }

                                        },
                                        Response.ErrorListener {
                                            Toast.makeText(
                                                this,
                                                "Some Error occurred!!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }) {
                                        override fun getHeaders(): MutableMap<String, String> {
                                            val headers = HashMap<String, String>()
                                            headers["Content-type"] = "application/json"
                                            headers["token"] = "2ecc7402475386"
                                            return headers
                                        }
                                    }
                                    queue.add(jsonObjectRequest)

                                } catch (e: JSONException) {
                                    Toast.makeText(
                                        this,
                                        "Some unexpected error occurred!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                            } else {
                                val dialog = AlertDialog.Builder(this)
                                dialog.setTitle("Error")
                                dialog.setMessage("Internet Connection not Found")
                                dialog.setPositiveButton("Open Settings") { _, _ ->

                                    val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                                    startActivity(settingsIntent)
                                    finish()

                                }
                                dialog.setNegativeButton("Exit") { _, _ ->
                                    ActivityCompat.finishAffinity(this)
                                }
                                dialog.create()
                                dialog.show()
                            }


                        } else {
                            etConfirmPassword.error = "Password doesn't match!"
                        }
                    }
                }
            }
        }

    }

    fun afterPasswordChange() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}