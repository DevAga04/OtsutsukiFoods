package com.otsutsuki.food.adapter

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.otsutsuki.food.R
import com.otsutsuki.food.activity.ResDetailsActivity
import com.otsutsuki.food.database.FavRestaurantEntity
import com.otsutsuki.food.model.Restaurant
import com.squareup.picasso.Picasso


class FavouriteRecyclerAdapter(val context: Context, private val favResList: List<FavRestaurantEntity>) :
    RecyclerView.Adapter<FavouriteRecyclerAdapter.FavouriteViewHolder>() {


    val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        context.getString(R.string.shared_preferences),
        Context.MODE_PRIVATE
    )


    class FavouriteViewHolder(view: View) : RecyclerView.ViewHolder(view) {


        val cardView: CardView = view.findViewById(R.id.singleFavCardView)
        val favDishImage: ImageView = view.findViewById(R.id.imgRecycle)
        val restaurantName: TextView = view.findViewById(R.id.txtRecycle)
        val price: TextView = view.findViewById(R.id.txtPrice)
        val favIcon: ImageView = view.findViewById(R.id.imgFavRecycle)
        val txtRating: TextView = view.findViewById(R.id.txtRating)


    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouriteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_fav_single_row, parent, false)

        return FavouriteViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavouriteViewHolder, position: Int) {

        val restaurant = favResList[position]

        holder.restaurantName.text = restaurant.name
        holder.txtRating.text = restaurant.rating
        holder.price.text = restaurant.costForOne
        Picasso.get().load(restaurant.imageUrl).error(R.drawable.ic_default_food_image)
            .into(holder.favDishImage)

        holder.cardView.setOnClickListener {
            val intent = Intent(context, ResDetailsActivity::class.java)

            sharedPreferences.edit().putString("favourite_res_id", restaurant.id.toString()).apply()
            sharedPreferences.edit().putString("favourite_res_name", restaurant.name).apply()

            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return favResList.size
    }

}