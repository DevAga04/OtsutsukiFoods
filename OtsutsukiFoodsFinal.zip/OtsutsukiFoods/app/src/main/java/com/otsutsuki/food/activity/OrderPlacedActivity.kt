package com.otsutsuki.food.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RelativeLayout
import com.otsutsuki.food.R

class OrderPlacedActivity : AppCompatActivity() {

    lateinit var btnOk: Button
    private lateinit var orderPlaced: RelativeLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_placed)

        orderPlaced = findViewById(R.id.orderPlaced)
        btnOk = findViewById(R.id.btnOk)

        btnOk.setOnClickListener {

            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }

    }

    override fun onBackPressed() {
        // removed super.onBackPressed() so that user can't go back
    }
}