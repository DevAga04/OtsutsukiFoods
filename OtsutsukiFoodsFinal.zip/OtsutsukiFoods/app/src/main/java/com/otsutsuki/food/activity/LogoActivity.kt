package com.otsutsuki.food.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.otsutsuki.food.R


class LogoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_logo)

        Handler().postDelayed({

            val sharedPreferences =
                getSharedPreferences(getString(R.string.shared_preferences), MODE_PRIVATE)

            if (sharedPreferences.getBoolean("isLoggedIn", false)) {
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }

        }, 1500)

    }

    override fun onPause() {
        super.onPause()
        finish()
    }


}



