package com.otsutsuki.food.fragment

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.otsutsuki.food.R
import com.otsutsuki.food.adapter.FavouriteRecyclerAdapter
import com.otsutsuki.food.database.FavRestaurantDatabase
import com.otsutsuki.food.database.FavRestaurantEntity


class FavResFragment : Fragment() {

    private lateinit var favRelativeLayout: RelativeLayout
    private lateinit var favRecycle: RecyclerView
    private lateinit var noFavRelativeLayout: RelativeLayout

    private lateinit var favProgressLayout: RelativeLayout
    private lateinit var favProgressBar: ProgressBar

    private lateinit var layoutManager: RecyclerView.LayoutManager
    private lateinit var recyclerAdapter: FavouriteRecyclerAdapter

    private var dbFavResList = listOf<FavRestaurantEntity>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_fav_res, container, false)

        favRelativeLayout = view.findViewById(R.id.favLayout)
        favRecycle = view.findViewById(R.id.favRecycle)
        noFavRelativeLayout = view.findViewById(R.id.noFavLayout)

        favProgressLayout = view.findViewById(R.id.favProgressLayout)
        favProgressBar = view.findViewById(R.id.favProgressBar)

        layoutManager = LinearLayoutManager(activity as Context)

        dbFavResList = RetrieveFavourite(activity as Context).execute().get()



        if (dbFavResList.isEmpty()) {

            noFavRelativeLayout.visibility = View.VISIBLE
            favProgressLayout.visibility = View.GONE
            favRelativeLayout.visibility = View.GONE

        } else {
            noFavRelativeLayout.visibility = View.GONE
            favRelativeLayout.visibility = View.VISIBLE
            favProgressLayout.visibility = View.GONE




            recyclerAdapter = FavouriteRecyclerAdapter(activity as Context, dbFavResList)
            favRecycle.adapter = recyclerAdapter
            favRecycle.layoutManager = layoutManager
        }

        return view
    }

    class RetrieveFavourite(val context: Context) :
        AsyncTask<Void, Void, List<FavRestaurantEntity>>() {
        override fun doInBackground(vararg params: Void?): List<FavRestaurantEntity> {

            val db =
                Room.databaseBuilder(context, FavRestaurantDatabase::class.java, "favourite-db")
                    .build()
            return db.favResDao().getAllRestaurant()
        }

    }


}