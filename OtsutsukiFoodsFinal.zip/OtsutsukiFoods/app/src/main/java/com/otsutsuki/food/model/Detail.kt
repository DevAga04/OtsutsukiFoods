package com.otsutsuki.food.model

data class Detail(
    val srNo: Int,
    val dishId: String,
    val dishName: String,
    val dishCost: String,
    val restaurantId: String
)