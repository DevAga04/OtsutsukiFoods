package com.otsutsuki.food.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.adapter.DashboardRecyclerAdapter
import com.otsutsuki.food.model.Restaurant
import com.otsutsuki.food.util.ConnectionManager
import kotlinx.android.synthetic.main.sort_menu.view.*
import org.json.JSONException
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap

class DashboardFragment : Fragment() {

    lateinit var recyclerDashboard: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager

    lateinit var recyclerAdapter: DashboardRecyclerAdapter
    private lateinit var sortButton: View

    lateinit var progressLayout: RelativeLayout
    private lateinit var progressBar: ProgressBar

    val resInfoList = arrayListOf<Restaurant>()

    //Sort according to Ratings
    private val ratingComparator = Comparator<Restaurant> { restaurant1, restaurant2 ->

        if (restaurant1.resRating.compareTo(restaurant2.resRating, true) == 0) {
            restaurant1.resName.compareTo(restaurant2.resName, true)
        } else {
            restaurant1.resRating.compareTo(restaurant2.resRating, true)
        }
    }

    //Sort according to Cost
    private val priceComparator = Comparator<Restaurant> { restaurant1, restaurant2 ->
        restaurant1.resPrice.compareTo(restaurant2.resPrice, true)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        setHasOptionsMenu(true)

        recyclerDashboard = view.findViewById(R.id.recyclerDashboard)


        progressLayout = view.findViewById(R.id.progressLayout)
        progressBar = view.findViewById(R.id.progressBar)

        progressLayout.visibility = View.VISIBLE

        layoutManager = LinearLayoutManager(activity)


        val queue = Volley.newRequestQueue(activity as Context)

        val url = "http://13.235.250.119/v2/restaurants/fetch_result/"


        if (ConnectionManager().checkConnectivity(activity as Context)) {
            //Internet is available

            val jsonObjectRequest =
                object : JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {


                    //Handling Response
                    println("response is $it")

                    try {
                        progressLayout.visibility = View.GONE

                        val data1 = it.getJSONObject("data")

                        val success = data1.getBoolean("success")

                        if (success) {
                            val data = data1.getJSONArray("data")
                            for (i in 0 until data.length()) {
                                val resJsonObject = data.getJSONObject(i)
                                val resObject = Restaurant(
                                    resJsonObject.getString("id"),
                                    resJsonObject.getString("name"),
                                    resJsonObject.getString("rating"),
                                    resJsonObject.getString("cost_for_one"),
                                    resJsonObject.getString("image_url")
                                )
                                resInfoList.add(resObject)

                                recyclerAdapter =
                                    DashboardRecyclerAdapter(activity as Context, resInfoList)

                                recyclerDashboard.adapter = recyclerAdapter

                                recyclerDashboard.layoutManager = layoutManager
                            }


                        } else {
                            Toast.makeText(
                                activity as Context,
                                "Some error has Occurred!!!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(
                            activity as Context,
                            "Some unexpected error occurred!!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }


                }, Response.ErrorListener {

                    //Handling Error
                    Toast.makeText(
                        activity as Context,
                        "Volley error occurred!!!",
                        Toast.LENGTH_SHORT
                    ).show()


                }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "2ecc7402475386"
                        return headers
                    }
                }

            queue.add(jsonObjectRequest)


        } else {
            //Internet is not available
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Open Settings") { _, _ ->

                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()

            }
            dialog.setNegativeButton("Exit") { _, _ ->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }



        return view
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_dashboard, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val id = item.itemId

        if (id == R.id.action_sort) {
            sortButton = View.inflate(context, R.layout.sort_menu, null)
            AlertDialog.Builder(activity as Context)
                .setTitle("Sort By?")
                .setView(sortButton)
                .setPositiveButton("Ok") { _, _ ->
                    if (sortButton.sort_high_to_low.isChecked) {
                        Collections.sort(resInfoList, priceComparator)
                        resInfoList.reverse()
                        recyclerAdapter.notifyDataSetChanged()
                    }
                    if (sortButton.sort_low_to_high.isChecked) {
                        Collections.sort(resInfoList, priceComparator)
                        recyclerAdapter.notifyDataSetChanged()
                    }
                    if (sortButton.sort_rating.isChecked) {
                        Collections.sort(resInfoList, ratingComparator)
                        resInfoList.reverse()
                        recyclerAdapter.notifyDataSetChanged()
                    }
                }
                .setNegativeButton("Cancel") { _, _ ->

                }
                .create()
                .show()
        }


        return super.onOptionsItemSelected(item)
    }


}