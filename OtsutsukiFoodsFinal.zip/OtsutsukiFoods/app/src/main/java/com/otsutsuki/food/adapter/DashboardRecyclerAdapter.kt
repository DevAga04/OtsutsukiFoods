package com.otsutsuki.food.adapter

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.otsutsuki.food.R
import com.otsutsuki.food.activity.ResDetailsActivity
import com.otsutsuki.food.database.FavRestaurantDatabase
import com.otsutsuki.food.database.FavRestaurantEntity
import com.otsutsuki.food.model.Restaurant
import com.squareup.picasso.Picasso

class DashboardRecyclerAdapter(val context: Context, private val itemList: ArrayList<Restaurant>) :
    RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>() {

    val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        context.getString(R.string.shared_preferences),
        Context.MODE_PRIVATE
    )


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_dashboard_single_row, parent, false)

        return DashboardViewHolder(view)
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val restaurant = itemList[position]
        holder.txtResName.text = restaurant.resName
        holder.txtCost.text = restaurant.resPrice
        holder.txtRating.text = restaurant.resRating
        Picasso.get().load(restaurant.resImage).error(R.drawable.ic_default_food_image)
            .into(holder.imgDish)

        holder.cdContent.setOnClickListener {
            val intent = Intent(context, ResDetailsActivity::class.java)
            sharedPreferences.edit().putString("favourite_res_id", restaurant.resId).apply()
            sharedPreferences.edit().putString("favourite_res_name", restaurant.resName).apply()
            context.startActivity(intent)
        }


        val listOfFavourites = GetAllFavAsyncTask(context).execute().get()

        if (listOfFavourites.isNotEmpty() && listOfFavourites.contains(restaurant.resId)) {
            holder.imgFav.setImageResource(R.drawable.ic_fav_checked)
        } else {
            holder.imgFav.setImageResource(R.drawable.ic_fav)
        }


        holder.imgFav.setOnClickListener {

            val restaurantEntity = FavRestaurantEntity(
                restaurant.resId.toInt(),
                restaurant.resName,
                restaurant.resRating,
                restaurant.resPrice,
                restaurant.resImage
            )

            if (!FavDBAsyncTask(context, restaurantEntity, 1).execute().get()) {

                val async = FavDBAsyncTask(context, restaurantEntity, 2).execute()
                val result = async.get()
                if (result) {
                    Toast.makeText(context, "Restaurant added to favourites", Toast.LENGTH_SHORT)
                        .show()
                    holder.imgFav.setImageResource(R.drawable.ic_fav_checked)
                } else {
                    Toast.makeText(context, "Some error occurred!!", Toast.LENGTH_SHORT)
                        .show()
                }
            } else {
                val async = FavDBAsyncTask(context, restaurantEntity, 3).execute()
                val result = async.get()

                if (result) {
                    Toast.makeText(
                        context,
                        "Restaurant removed from favourites",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                    holder.imgFav.setImageResource(R.drawable.ic_fav)
                } else {
                    Toast.makeText(context, "Some error occurred!!", Toast.LENGTH_SHORT)
                        .show()
                }

            }


        }
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    class DashboardViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtResName: TextView = view.findViewById(R.id.txtRecycle)
        val txtCost: TextView = view.findViewById(R.id.txtPrice)
        val txtRating: TextView = view.findViewById(R.id.txtRating)
        val imgDish: ImageView = view.findViewById(R.id.imgRecycle)
        val cdContent: CardView = view.findViewById(R.id.singleCardView)
        val imgFav: ImageView = view.findViewById(R.id.imgFavRecycle)

    }


    class FavDBAsyncTask(
        val context: Context,
        private val favRestaurantEntity: FavRestaurantEntity,
        private val mode: Int
    ) : AsyncTask<Void, Void, Boolean>() {

        /*
        * Mode 1 -> Check DB if the restaurant is favourite or not.
        * Mode 2 -> Save the restaurant into DB as favourite.
        * Mode 3 -> Remove the favourite book.
         */

        private val db =
            Room.databaseBuilder(context, FavRestaurantDatabase::class.java, "favourite-db").build()


        override fun doInBackground(vararg p0: Void?): Boolean {

            when (mode) {
                1 -> {

                    //Check DB if the restaurant is favourite or not.
                    val restaurant: FavRestaurantEntity? =
                        db.favResDao().getResById(favRestaurantEntity.id.toString())
                    db.close()
                    return restaurant != null

                }
                2 -> {

                    //Save the restaurant into DB as favourite.
                    db.favResDao().insertRestaurant(favRestaurantEntity)
                    db.close()
                    return true

                }
                3 -> {

                    //Remove the favourite book.
                    db.favResDao().deleteRestaurant(favRestaurantEntity)
                    db.close()
                    return true

                }
            }


            return false
        }
    }

    class GetAllFavAsyncTask(
        context: Context
    ) :
        AsyncTask<Void, Void, List<String>>() {

        private val db =
            Room.databaseBuilder(context, FavRestaurantDatabase::class.java, "favourite-db").build()

        override fun doInBackground(vararg params: Void?): List<String> {

            val list = db.favResDao().getAllRestaurant()
            val listOfIds = arrayListOf<String>()
            for (i in list) {
                listOfIds.add(i.id.toString())
            }
            return listOfIds
        }
    }

}