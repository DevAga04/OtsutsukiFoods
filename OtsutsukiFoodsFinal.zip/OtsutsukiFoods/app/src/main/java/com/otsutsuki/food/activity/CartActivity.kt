package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.adapter.CartRecyclerAdapter
import com.otsutsuki.food.model.CartItems
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class CartActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var txtCartResName: TextView

    lateinit var cartRecyclerView: RecyclerView
    lateinit var btnRelativeLayout: RelativeLayout
    lateinit var btnPlaceOrder: Button

    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: CartRecyclerAdapter

    private lateinit var restaurantId: String
    private lateinit var restaurantName: String
    lateinit var selectedItemsId: ArrayList<String>

    var totalAmount = 0
    var cartListItems = arrayListOf<CartItems>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        btnPlaceOrder = findViewById(R.id.btnPlaceOrder)
        txtCartResName = findViewById(R.id.txtCartResName)
        toolbar = findViewById(R.id.cartToolbar)







        if (intent != null) {
            restaurantId = intent.getStringExtra("restaurantId").toString()
            restaurantName = intent.getStringExtra("restaurantName").toString()
            selectedItemsId = intent.getStringArrayListExtra("selectedItemsId") as ArrayList<String>

        } else {
            Toast.makeText(this, "Some Error Occurred 1 !!", Toast.LENGTH_SHORT).show()
        }

        txtCartResName.text = restaurantName

        setSupportActionBar(toolbar)
        supportActionBar?.title = "My Cart"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        if (ConnectionManager().checkConnectivity(this)) {

            try {

                val queue = Volley.newRequestQueue(this)
                val url = "http://13.235.250.119/v2/restaurants/fetch_result/$restaurantId"

                val jsonObjectRequest =
                    object : JsonObjectRequest(Method.GET, url, null, Response.Listener {

                        print("Response is $it")

                        val response = it.getJSONObject("data")
                        val success = response.getBoolean("success")
                        if (success) {

                            val data = response.getJSONArray("data")
                            cartListItems.clear()
                            totalAmount = 0

                            for (i in 0 until data.length()) {
                                val cartItem = data.getJSONObject(i)
                                if (selectedItemsId.contains(cartItem.getString("id"))) {
                                    val menuItem = CartItems(
                                        cartItem.getString("id"),
                                        cartItem.getString("name"),
                                        cartItem.getString("cost_for_one"),
                                        cartItem.getString("restaurant_id")
                                    )

                                    totalAmount += cartItem.getString("cost_for_one").toString()
                                        .toInt()

                                    cartListItems.add(menuItem)

                                }
                                recyclerAdapter = CartRecyclerAdapter(this, cartListItems)
                                cartRecyclerView.adapter = recyclerAdapter
                                cartRecyclerView.layoutManager = layoutManager
                            }

                            btnPlaceOrder.text = "Place Order (Total: Rs. $totalAmount)"
                        } else {
                            Toast.makeText(
                                this,
                                "Some error has Occurred  4 !!!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    }, Response.ErrorListener {
                        Toast.makeText(
                            this,
                            "Some error occurred 5 !!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Content-type"] = "application/json"
                            headers["token"] = "2ecc7402475386"
                            return headers
                        }
                    }
                queue.add(jsonObjectRequest)

            } catch (e: JSONException) {
                Toast.makeText(
                    this,
                    "Some Unexpected error occurred 6 !!!",
                    Toast.LENGTH_SHORT
                ).show()
            }

        } else {
            val dialog = AlertDialog.Builder(this)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Open Settings") { _, _ ->

                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                finish()

            }
            dialog.setNegativeButton("Exit") { _, _ ->
                ActivityCompat.finishAffinity(this)
            }
            dialog.create()
            dialog.show()
        }











        btnPlaceOrder.setOnClickListener {

            val sharedPreferences =
                getSharedPreferences(getString(R.string.shared_preferences), MODE_PRIVATE)

            if (ConnectionManager().checkConnectivity(this)) {

                try {
                    val foodArray = JSONArray()

                    for (foodItem in selectedItemsId) {
                        val singleItemObject = JSONObject()
                        singleItemObject.put("food_item_id", foodItem)
                        foodArray.put(singleItemObject)
                    }

                    val sendOrder = JSONObject()
                    sendOrder.put("user_id", sharedPreferences.getString("user_id", "0"))
                    sendOrder.put("restaurant_id", restaurantId)
                    sendOrder.put("total_cost", totalAmount)
                    sendOrder.put("food", foodArray)

                    val queue = Volley.newRequestQueue(this)
                    val url = "http://13.235.250.119/v2/place_order/fetch_result"

                    val jsonObjectRequest =
                        object : JsonObjectRequest(Method.POST, url, sendOrder, Response.Listener {


                            val response = it.getJSONObject("data")
                            val success = response.getBoolean("success")
                            if (success) {

                                Toast.makeText(
                                    this,
                                    "Order Placed",
                                    Toast.LENGTH_SHORT
                                ).show()

                                createNotification()

                                val intent = Intent(this, OrderPlacedActivity::class.java)
                                startActivity(intent)
                                finish()

                            } else {
                                val errorMessage =
                                    response.getString("errorMessage")
                                Toast.makeText(
                                    this,
                                    errorMessage.toString(),
                                    Toast.LENGTH_SHORT
                                ).show()

                            }

                        }, Response.ErrorListener {
                            Toast.makeText(
                                this,
                                "Some Error occurred 2 !!!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }) {
                            override fun getHeaders(): MutableMap<String, String> {
                                val headers = HashMap<String, String>()
                                headers["Content-type"] = "application/json"
                                headers["token"] = "2ecc7402475386"
                                return headers
                            }
                        }
                    queue.add(jsonObjectRequest)

                } catch (e: JSONException) {
                    Toast.makeText(
                        this,
                        "Some unexpected error occurred 3 !!",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            } else {
                val dialog = AlertDialog.Builder(this)
                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection not Found")
                dialog.setPositiveButton("Open Settings") { _, _ ->

                    val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingsIntent)
                    finish()

                }
                dialog.setNegativeButton("Exit") { _, _ ->
                    ActivityCompat.finishAffinity(this)
                }
                dialog.create()
                dialog.show()
            }

        }

        cartRecyclerView = findViewById(R.id.recyclerViewCart)
        layoutManager = LinearLayoutManager(this)

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home ->
                finish()

        }
        return true
    }


    fun createNotification() {
        val notificationId = 1
        val channelId = "personal_notification"
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
        notificationBuilder.setSmallIcon(R.drawable.ic_default_food_image)
        notificationBuilder.setContentTitle("Order Placed")
        notificationBuilder.setContentText("Your order has been successfully placed!")
        notificationBuilder.setStyle(
            NotificationCompat.BigTextStyle()
                .bigText("Ordered from ${restaurantName}. Please pay Rs.$totalAmount")
        )

        notificationBuilder.priority = NotificationCompat.PRIORITY_DEFAULT
        val notificationManagerCompat = NotificationManagerCompat.from(this)
        notificationManagerCompat.notify(notificationId, notificationBuilder.build())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Order Placed"
            val description = "Your order has been successfully placed!"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val notificationChannel = NotificationChannel(channelId, name, importance)
            notificationChannel.description = description

            val notificationManager =
                (getSystemService(Context.NOTIFICATION_SERVICE)) as NotificationManager

            notificationManager.createNotificationChannel(notificationChannel)
        }
    }
}