package com.otsutsuki.food.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ContextMenu
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.adapter.OrderHistoryRecyclerAdapter
import com.otsutsuki.food.model.OrderHistoryRestaurant
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException


class OrderHistoryFragment : Fragment() {


    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: OrderHistoryRecyclerAdapter
    lateinit var recyclerView: RecyclerView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,

        ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_order_history, container, false)

        recyclerView = view.findViewById(R.id.orderHistoryRecyclerView)

        layoutManager = LinearLayoutManager(context)

        val orderedRestaurantList = ArrayList<OrderHistoryRestaurant>()
        val sharedPreferences = activity?.getSharedPreferences(
            getString(R.string.shared_preferences),
            Context.MODE_PRIVATE
        )

        val userId = sharedPreferences?.getString("user_id", "0")
        if (ConnectionManager().checkConnectivity(activity as Context)) {

            try {
                val queue = Volley.newRequestQueue(activity as Context)
                val url = "http://13.235.250.119/v2/orders/fetch_result/$userId"

                val jsonObjectRequest =
                    object : JsonObjectRequest(Method.GET, url, null, Response.Listener {


                        val response = it.getJSONObject("data")
                        val success = response.getBoolean("success")

                        if (success) {
                            val data = response.getJSONArray("data")
                            if (data.length() == 0) {
                                Toast.makeText(
                                    context,
                                    "No Orders Placed yet!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                for (i in 0 until data.length()) {
                                    val restaurantItem = data.getJSONObject(i)
                                    val restaurantObject = OrderHistoryRestaurant(
                                        restaurantItem.getString("order_id"),
                                        restaurantItem.getString("restaurant_name"),
                                        restaurantItem.getString("total_cost"),
                                        restaurantItem.getString("order_placed_at").substring(0, 10)
                                    )

                                    orderedRestaurantList.add(restaurantObject)
                                    recyclerAdapter = OrderHistoryRecyclerAdapter(
                                        activity as Context,
                                        orderedRestaurantList
                                    )
                                    recyclerView.adapter = recyclerAdapter
                                    recyclerView.layoutManager = layoutManager
                                }
                            }
                        }


                    }, Response.ErrorListener {
                        Toast.makeText(
                            context,
                            "Some Error occurred!!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Context-type"] = "application/json"
                            headers["token"] = "2ecc7402475386"
                            return headers
                        }
                    }
                queue.add(jsonObjectRequest)

            } catch (e: JSONException) {
                Toast.makeText(
                    context,
                    "Some Unexpected error occurred!!!",
                    Toast.LENGTH_SHORT
                ).show()
            }


        } else {
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Open Settings") { _, _ ->

                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)

            }
            dialog.setNegativeButton("Exit") { _, _ ->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }


        return view
    }


}