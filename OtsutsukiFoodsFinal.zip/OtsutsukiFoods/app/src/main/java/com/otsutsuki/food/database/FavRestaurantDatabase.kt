package com.otsutsuki.food.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [FavRestaurantEntity::class], version = 1)
abstract class FavRestaurantDatabase : RoomDatabase() {

    abstract fun favResDao(): FavRestaurantDao

}