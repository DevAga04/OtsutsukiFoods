package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.otsutsuki.food.R
import com.otsutsuki.food.util.ConnectionManager
import org.json.JSONException
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var btnForgotPassword: Button
    private lateinit var btnNewUser: Button
    private lateinit var btnLogin: Button

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnForgotPassword = findViewById(R.id.btnForgetPassword)
        btnNewUser = findViewById(R.id.btnNewUser)
        btnLogin = findViewById(R.id.btnLogin)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)

        btnLogin.setOnClickListener {

            if (etUsername.text.isBlank() || etUsername.text.length != 10) {
                Toast.makeText(this, "Enter Valid Username", Toast.LENGTH_SHORT).show()
            } else {
                if (etPassword.text.isBlank() || etPassword.text.length <= 4) {
                    Toast.makeText(this, "Enter valid Password", Toast.LENGTH_SHORT).show()
                } else {
                    loginUser()
                }
            }
        }

        btnForgotPassword.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgetPasswordActivity::class.java)
            startActivity(intent)
        }

        btnNewUser.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }

    }


    private fun loginUser() {
        val sharedPreferences =
            getSharedPreferences(getString(R.string.shared_preferences), MODE_PRIVATE)
        if (ConnectionManager().checkConnectivity(this)) {
            try {
                val loginUser = JSONObject()
                loginUser.put("mobile_number", etUsername.text)
                loginUser.put("password", etPassword.text)

                val queue = Volley.newRequestQueue(this)
                val url = "http://13.235.250.119/v2/login/fetch_result/"
                val jsonObjectRequest =
                    object : JsonObjectRequest(Method.POST, url, loginUser, Response.Listener {

                        val response = it.getJSONObject("data")
                        val success = response.getBoolean("success")
                        if (success) {
                            val data = response.getJSONObject("data")
                            sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
                            sharedPreferences.edit().putString("user_id", data.getString("user_id"))
                                .apply()
                            sharedPreferences.edit().putString("name", data.getString("name"))
                                .apply()
                            sharedPreferences.edit().putString("email", data.getString("email"))
                                .apply()
                            sharedPreferences.edit()
                                .putString("mobile_number", data.getString("mobile_number")).apply()
                            sharedPreferences.edit().putString("address", data.getString("address"))
                                .apply()

                            Toast.makeText(
                                this,
                                "Welcome " + data.getString("name"),
                                Toast.LENGTH_LONG
                            ).show()

                            userLoggedInSuccessfully()
                        } else {
                            val responseErrorMessage = response.getString("errorMessage")

                            Toast.makeText(
                                this,
                                responseErrorMessage.toString(),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }, Response.ErrorListener {
                        Toast.makeText(this, "Some Error Occurred!!", Toast.LENGTH_SHORT).show()


                    }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Context-type"] = "application/json"
                            headers["token"] = "2ecc7402475386"
                            return headers
                        }
                    }
                queue.add(jsonObjectRequest)


            } catch (e: JSONException) {

                Toast.makeText(
                    this,
                    "Some unexpected error occurred!!",
                    Toast.LENGTH_SHORT
                ).show()

            }

        } else {
            val dialog = AlertDialog.Builder(this)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Open Settings") { _, _ ->

                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                finish()

            }
            dialog.setNegativeButton("Exit") { _, _ ->
                ActivityCompat.finishAffinity(this)
            }
            dialog.create()
            dialog.show()
        }
    }

    fun userLoggedInSuccessfully() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}
