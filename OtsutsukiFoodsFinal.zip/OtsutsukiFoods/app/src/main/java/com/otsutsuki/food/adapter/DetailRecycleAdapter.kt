package com.otsutsuki.food.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.otsutsuki.food.R
import com.otsutsuki.food.activity.CartActivity
import com.otsutsuki.food.model.Detail

class DetailRecycleAdapter(
    val context: Context,
    val itemList: ArrayList<Detail>,
    private val proceedToCartLayout: RelativeLayout,
    private val proceedToCartButton: Button,
    private val restaurantId: String,
    private val restaurantName: String
) :
    RecyclerView.Adapter<DetailRecycleAdapter.DetailViewHolder>() {

    private var itemSelectedCount = 0
    private lateinit var proceedToCard: RelativeLayout
    var selectedDishId = arrayListOf<String>()

    class DetailViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val srNumber: TextView = view.findViewById(R.id.detailRowNumber)
        val dishName: TextView = view.findViewById(R.id.txtDishName)
        val dishPrice: TextView = view.findViewById(R.id.txtDishPrice)
        val dishButton: Button = view.findViewById(R.id.btnAddDetail)

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_details_single_row, parent, false)

        return DetailViewHolder(view)
    }

    override fun onBindViewHolder(holder: DetailViewHolder, position: Int) {
        val dish = itemList[position]
        proceedToCard = proceedToCartLayout

        holder.dishName.text = dish.dishName
        holder.dishPrice.text = dish.dishCost
        holder.srNumber.text = dish.srNo.toString()

        proceedToCartButton.setOnClickListener {
            val intent = Intent(context, CartActivity::class.java)
            intent.putExtra("restaurantId", restaurantId)
            intent.putExtra("restaurantName", restaurantName)
            intent.putExtra("selectedItemsId", selectedDishId)
            context.startActivity(intent)
        }



        holder.dishButton.setOnClickListener {

            if (holder.dishButton.text.toString() == "Remove") {

                itemSelectedCount--
                selectedDishId.remove(holder.dishButton.tag.toString())
                holder.dishButton.text = "Add"
                holder.dishButton.setBackgroundColor(Color.rgb(176, 91, 59))


            } else {

                itemSelectedCount++
                selectedDishId.add(holder.dishButton.tag.toString())
                holder.dishButton.text = "Remove"
                holder.dishButton.setBackgroundColor(Color.rgb(255, 196, 8))


            }


            if (itemSelectedCount > 0) {
                proceedToCard.visibility = View.VISIBLE
            } else {
                proceedToCard.visibility = View.GONE
            }
        }

        holder.dishButton.tag = dish.dishId + ""
        holder.dishName.text = dish.dishName
        holder.dishPrice.text = dish.dishCost

    }

    override fun getItemCount(): Int {
        return itemList.size
    }


    fun getSelectedItemCount(): Int {
        return itemSelectedCount
    }
}