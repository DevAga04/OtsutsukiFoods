package com.otsutsuki.food.fragment

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.otsutsuki.food.R


class UserProfileFragment : Fragment() {

    private lateinit var txtName: TextView
    lateinit var txtNumber: TextView
    private lateinit var txtEmail: TextView
    private lateinit var txtAddress: TextView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_user_profile, container, false)

        txtName = view.findViewById(R.id.profileName)
        txtNumber = view.findViewById(R.id.profileNumber)
        txtEmail = view.findViewById(R.id.profileEmail)
        txtAddress = view.findViewById(R.id.profileAddress)

        val sharedPreferences = activity?.getSharedPreferences(
            getString(R.string.shared_preferences),
            Context.MODE_PRIVATE
        )

        txtName.text = sharedPreferences?.getString("name", "")
        txtNumber.text = "+91-" + sharedPreferences?.getString("mobile_number", "")
        txtEmail.text = sharedPreferences?.getString("email", "")
        txtAddress.text = sharedPreferences?.getString("address", "")

        return view
    }


}