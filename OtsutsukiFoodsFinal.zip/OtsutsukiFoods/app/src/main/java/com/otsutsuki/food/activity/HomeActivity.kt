package com.otsutsuki.food.activity

import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.otsutsuki.food.R
import com.otsutsuki.food.fragment.*


class HomeActivity : AppCompatActivity() {


    private lateinit var drawerLayout: DrawerLayout
    private lateinit var coordinatorLayout: CoordinatorLayout
    private lateinit var toolbar: Toolbar
    private lateinit var frameLayout: FrameLayout
    private lateinit var navigationView: NavigationView
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var txtUser: TextView
    lateinit var txtNumber: TextView

    private var previousMenuItem: MenuItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        sharedPreferences =
            getSharedPreferences(getString(R.string.shared_preferences), MODE_PRIVATE)

        drawerLayout = findViewById(R.id.drawerLayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        toolbar = findViewById(R.id.toolbar)
        frameLayout = findViewById(R.id.frame)
        navigationView = findViewById(R.id.navigation)

        val headerView = navigationView.getHeaderView(0)
        txtUser = headerView.findViewById(R.id.headerUsername)
        txtNumber = headerView.findViewById(R.id.headerUserNumber)

        navigationView.menu.getItem(0).isCheckable = true
        navigationView.menu.getItem(0).isChecked = true



        setUpToolbar()

        txtUser.text = sharedPreferences.getString("name", "Username")
        txtNumber.text = "+91- ${sharedPreferences.getString("mobile_number", "0123456789")}"

        //Dashboard as default
        openDashboard()


        val actionBarDrawerToggle = ActionBarDrawerToggle(
            this@HomeActivity,
            drawerLayout,
            R.string.open_drawer,
            R.string.close_drawer
        )

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()


        navigationView.setNavigationItemSelectedListener {


            if (previousMenuItem != null) {
                previousMenuItem?.isChecked = false
            }

            it.isCheckable = true
            it.isChecked = true
            previousMenuItem = it

            when (it.itemId) {
                R.id.dashboard -> {
                    openDashboard()

                    drawerLayout.closeDrawers()
                }
                R.id.favRes -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, FavResFragment())

                        .commit()

                    supportActionBar?.title = "Favourites Restaurant"
                    drawerLayout.closeDrawers()
                }
                R.id.userProfile -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, UserProfileFragment())

                        .commit()

                    supportActionBar?.title = "My Profile"
                    drawerLayout.closeDrawers()
                }
                R.id.orderHistory -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, OrderHistoryFragment())

                        .commit()

                    supportActionBar?.title = "My Previous Orders"
                    drawerLayout.closeDrawers()
                }
                R.id.FAQ -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, FAQFragment())

                        .commit()

                    supportActionBar?.title = "Frequently Asked Questions"
                    drawerLayout.closeDrawers()
                }
                R.id.logOut -> {
                    val dialog = AlertDialog.Builder(this@HomeActivity)
                    dialog.setTitle("Log Out")
                    dialog.setMessage("Do you want to logout?")
                    dialog.setPositiveButton("Ok") { _, _ ->
                        sharedPreferences.edit().putBoolean("isLoggedIn", false).apply()
                        ActivityCompat.finishAffinity(this)

                    }
                    dialog.setNegativeButton("Cancel") { _, _ ->
                        //Do Nothing
                    }
                    dialog.create()
                    dialog.show()
                    it.isCheckable = false
                    it.isChecked = false
                    drawerLayout.closeDrawers()
                }
            }

            return@setNavigationItemSelectedListener true
        }


    }

    private fun setUpToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Toolbar title"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        if (id == android.R.id.home) {
            drawerLayout.openDrawer(GravityCompat.START)
        }


        return super.onOptionsItemSelected(item)
    }

    private fun openDashboard() {
        val fragment = DashboardFragment()
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frame, fragment)
        transaction.commit()
        supportActionBar?.title = "All Restaurant"
        navigationView.setCheckedItem(R.id.dashboard)
    }

    override fun onBackPressed() {

        when (supportFragmentManager.findFragmentById(R.id.frame)) {
            !is DashboardFragment -> openDashboard()

            else -> super.onBackPressed()
        }


    }

}